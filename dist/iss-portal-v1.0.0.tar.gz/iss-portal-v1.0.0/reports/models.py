from django.db import models

# Reports app doesn't have its own models
# It generates reports from core app models
