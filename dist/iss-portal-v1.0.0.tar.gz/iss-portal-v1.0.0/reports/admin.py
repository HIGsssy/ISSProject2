from django.contrib import admin

# Reports app doesn't have its own models, so no admin configuration needed
